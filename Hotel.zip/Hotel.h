// Integrante 1: Juan Esteban Salas
// Integrante 2: Harold David Guerrero
// Archivo: Hotel.h
#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <algorithm>

using namespace std;

#ifndef HOTEL_H
#define HOTEL_H

class Huesped {
private:
    string nombre;
    string apellido;
    string telefono;
    string correo;
    double saldo;

public:
    Huesped(string n, string a, string t, string c, double s)
            : nombre(n), apellido(a), telefono(t), correo(c), saldo(s) {}

    string getNombre() { return nombre; }
    string getApellido() { return apellido; }
    string getTelefono() { return telefono; }
    string getCorreo() { return correo; }
    double getSaldo() { return saldo; }

    bool operator==(Huesped& other) {
        return nombre == other.nombre && apellido == other.apellido && telefono == other.telefono && correo == other.correo && saldo == other.saldo;
    }

    void actualizarSaldo(double monto) {
        saldo -= monto;
    }
};

class Habitacion {
private:
    int numero;
    string tipo;
    double precioPorNoche;
    bool ocupada;

public:
    Habitacion(int num, string t, double precio)
            : numero(num), tipo(t), precioPorNoche(precio), ocupada(false) {}

    int getNumero() { return numero; }
    string getTipo() { return tipo; }
    double getPrecioPorNoche() { return precioPorNoche; }
    bool estaOcupada() { return ocupada; }
    void ocupar() { ocupada = true; }
    void desocupar() { ocupada = false; }
};

class Reserva {
private:
    Huesped *huesped;
    Habitacion *habitacion;
    int numNoches;

public:
    Reserva(Huesped& h, Habitacion& hab, int noches)
        : huesped(&h), habitacion(&hab), numNoches(noches) {}
            

    double calcularCostoTotal() {
        return numNoches * habitacion->getPrecioPorNoche();
    }

    void mostrarDetalles() {
        cout << "===========================================" << endl;
        cout << "Reserva para: " << huesped->getNombre() << " " << huesped->getApellido() << endl;
        cout << "Habitacion: " << habitacion->getNumero() << " (" << habitacion->getTipo() << ")" << endl;
        cout << "Costo total: $" << calcularCostoTotal() << endl;
        cout << "Numero de noches: " << numNoches << endl;
    }

    Habitacion* getHabitacion() {return habitacion;}
    Huesped* getHuesped() {return huesped;}
    int getNumNoches() {return numNoches;}


};

class Pago {
private:
    double monto;
    Reserva reserva;

public:
    Pago(double m, Reserva& r) : monto(m), reserva(r) {}

    double getMonto() { return monto; }
    Reserva& getReserva() { return reserva; }
};

class Hotel {
private:
    vector<Habitacion> habitaciones;
    vector<Reserva> reservas;
    vector<Pago> pagos;

public:
    Hotel() {
        for (int i = 101; i <= 110; ++i) {
            double precio = 50.0 + (rand() % 101);
            Habitacion hab(i, "Individual", precio);
            habitaciones.push_back(hab);
        }
    }

    void agregarHabitacion(const Habitacion& hab) {
        habitaciones.push_back(hab);
    }

    void hacerReserva(Huesped& h, int numeroHabitacion, int noches) {
        Habitacion* hab = nullptr;
        for (Habitacion& habitacion : habitaciones) {
            if (habitacion.getNumero() == numeroHabitacion && !habitacion.estaOcupada()) {
                hab = &habitacion;
                break;
            }
        }

        if (hab) {
            double costoReserva = hab->getPrecioPorNoche() * noches;
            if (h.getSaldo() >= costoReserva) {
                Reserva nuevaReserva(h, *hab, noches);
                reservas.push_back(nuevaReserva);
                hab->ocupar();
                registrarPago(costoReserva, nuevaReserva);
                h.actualizarSaldo(costoReserva);
                cout << "Reserva realizada exitosamente." << endl;

            } else {
                cout << "No tienes suficiente saldo para realizar la reserva." << endl;
            }
        } else {
            cout << "=============Reserva fallida============" << endl;
            cout << "La habitacion no esta disponible o no existe." << endl;
        }
    }

    void registrarPago(double monto,Reserva& r) {
        Pago nuevoPago(monto, r);
        pagos.push_back(nuevoPago);
    }

    void mostrarHabitacionesDisponibles() {
        cout << "=========================" <<endl;
        cout << "Habitaciones disponibles:" << endl;
        for (Habitacion& hab : habitaciones) {
            if (!hab.estaOcupada()) {
                cout << "Habitacion " << hab.getNumero() << " (" << hab.getTipo() << ")" << endl;
            }
        }
    }

    void mostrarInformeHabitaciones() {
        cout << "=========================" <<endl;
        cout << "Informe del estado de las habitaciones:" << endl;

        for ( Habitacion& hab : habitaciones) {
            cout << "Habitacion " << hab.getNumero() << " (" << hab.getTipo() << "): ";
            if (hab.estaOcupada()) {
                bool encontrada = false;
                for ( Reserva& res : reservas) {
                    if (res.getHabitacion()->getNumero() == hab.getNumero()) {
                        cout << "Ocupada por " << res.getHuesped()->getNombre() << " " << res.getHuesped()->getApellido();
                        cout << " (" << res.getNumNoches() << " noches) | ";
                        cout << "Correo: " << res.getHuesped()->getCorreo();
                        cout << " | Numero Telefonico: " << res.getHuesped()->getTelefono();
                        cout << " | Saldo: " << res.getHuesped()->getSaldo() << endl;
                        encontrada = true;
                        break;
                    }
                }
                if (!encontrada) {
                    cout << "Disponible" << endl;
                }
            } else {
                cout << "Disponible" << endl;
            }
        }
    }

    void cancelarReserva(Huesped& h, int numeroHabitacion) {
        for (auto it = reservas.begin(); it != reservas.end(); ++it) {
            if (it->getHuesped()->getNombre() == h.getNombre() && it->getHabitacion()->getNumero() == numeroHabitacion) {
                double montoReembolso = it->calcularCostoTotal();
                registrarPago(-montoReembolso, *it);
                it->getHabitacion()->desocupar();
                it->getHuesped()->actualizarSaldo(-montoReembolso);
                cout << "Reserva cancelada exitosamente. Se reembolso $" << montoReembolso << " al huesped " << it->getHuesped()->getNombre() << "." << endl;
                reservas.erase(it);
                return;
            }
        }
        cout << "No se encontro la reserva correspondiente para cancelar." << endl;
    }


    vector<Reserva>& getReservas() {
        return reservas;
    }
};


#endif //HOTEL_H
