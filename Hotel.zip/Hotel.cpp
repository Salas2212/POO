// Integrante 1: Juan Esteban Salas
// Integrante 2: Harold David Guerrero
// Archivo: Hotel.cpp

#include "Hotel.h"
#include <iostream>


int main() {
    Hotel hotel;
    //Se muestra las habitaciones disponibles
    hotel.mostrarHabitacionesDisponibles();
    //Se registra un Huesped
    Huesped huesped1("Juan", "Salas", "3015288040", "salas22@javerianacali.edu.co",274);
    //Se hace la reserva con una habitacion disponible
    hotel.hacerReserva(huesped1, 101, 3);
    //Se vuelve a mostra las habitaciones disponibles
    hotel.mostrarHabitacionesDisponibles();
    //Se registra otro Huesped
    Huesped huesped2("Harold", "Guerrero", "4242552", "hola@gmail.com",790);
    //Se hace la reserva con la habitacion anterior
    hotel.hacerReserva(huesped1, 101, 6); //Le muestra que la habitacion no esta disponible o no existe
    //Se hace la reserva con una habitacion disponible
    hotel.hacerReserva(huesped2, 105, 6);
    //Se muestran las reservas hechas en el hotel
    for (Reserva& reserva : hotel.getReservas()) {
        reserva.mostrarDetalles();
    }
    //Informe de habitaciones
    //Este informe es parecido a la funcion mostrarHabitacionesDisponibles pero decidimos dejar las dos ya que creemos que la funcion mostrarInformeHabitaciones() es para uso del hotel ya que no seria etico que cualquier persona pudiera ver el nombre y las noches en las que se hospeda alguien
    hotel.mostrarInformeHabitaciones();

    //Funcion para cancelar la reserva
    hotel.cancelarReserva(huesped1,101);
    //Verificar que la reserva se canceló
    hotel.mostrarInformeHabitaciones();

    return 0;
}
